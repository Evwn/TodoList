## About Laravel CRUD in 50 minutes for Beginners  from Scratch

This project is created to show you how to implement CRUD operations in Laravel with ease. Laravel will be used to create, read, update, and delete data from a database. 

If you want learn more about this project. You can visit [Laravel CRUD in 50 minutes for Beginners  from Scratch](https://youtu.be/_LA9QsgJ0bw) 



